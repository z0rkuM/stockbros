import { Component } from '@angular/core';

import { User } from './user';

@Component({
  selector: 'login',
  templateUrl: './html/login.component.html',
  styleUrls: ['./css/login.component.css']
})
export class LoginComponent  { 

  model = new User('', '');

  onSubmit(){
    console.log("entramos en submit");
  }
}
