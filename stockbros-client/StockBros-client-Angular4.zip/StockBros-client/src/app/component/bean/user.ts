export class User{
    
    name: string;
    password: string;

    constructor(
        name: string,
        password: string
    ) {  }
}