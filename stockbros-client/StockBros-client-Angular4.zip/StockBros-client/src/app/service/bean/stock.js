"use strict";
var Stock = (function () {
    function Stock(chart_time_period, date_update, market, percent, price, stock, uri) {
        this.chart_time_period = chart_time_period;
        this.date_update = date_update;
        this.market = market;
        this.percent = percent;
        this.price = price;
        this.stock = stock;
        this.uri = uri;
    }
    return Stock;
}());
exports.Stock = Stock;
//# sourceMappingURL=stock.js.map