import { Component } from '@angular/core';
import { StocksService } from '../service/stocks.service';

@Component({
  selector: 'stocks',
  templateUrl: './html/stocks.component.html',
  styleUrls: ['./css/stocks.component.css']
})

export class StocksComponent  { 

  constructor(
    private stocksService: StocksService
  ) { }

  ngOnInit() {
    console.log("************************Inicio*******************************");
    this.stocksService.getStocks();
    console.log("*************************Fin*********************************");
    console.log("stocks number: " + this.stocksService.results.length);
  }

}