import { Component } from '@angular/core';

import { User } from './user';
import { LoginService } from './login.service';

@Component({
  selector: 'login',
  templateUrl: './html/login.component.html',
  styleUrls: ['./css/login.component.css']
})

export class LoginComponent  { 

  model: User = new User('', '');

  constructor(
    private loginService: LoginService
  ){}

  onSubmit(){
    console.log(this.loginService.doLogin(this.model.name, this.model.password));
  }
}
