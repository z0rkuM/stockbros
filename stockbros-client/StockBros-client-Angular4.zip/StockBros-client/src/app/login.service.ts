import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';

import 'rxjs/add/operator/toPromise';

@Injectable()
export class LoginService{
    private loginUrl = 'http://localhost:5000/StockBros/auth';

    constructor (private http: Http){ }

    doLogin(username: string, password: string): Promise<string>{
        let base64hash = 'Basic ' + btoa(username + ":" + password)
        let headers = new Headers();
        headers.append('Authorization', base64hash); 
        return this.http.get(this.loginUrl, {headers: headers})
            .toPromise()
            .then(response => response.json() as string)
            .catch(this.handleError);
    }

    logout() {
        localStorage.removeItem('currentUser');
    }

    private handleError(error: any): Promise<any> {
		console.error('An error occurred', error); // for demo purposes only
		return Promise.reject(error.message || error);
	}
}