import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }   from '@angular/forms';
import { HttpModule }    from '@angular/http';

import { AppRoutingModule } from './app-routing.module';

//Components
import { AppComponent }  from './component/app.component';
import { LoginComponent }  from './component/login.component';
import { AlertComponent }  from './component/alert.component';
import { StocksComponent }  from './component/stocks.component';

//Services
import { LoginService }  from './service/login.service';
import { AlertService }  from './service/alert.service';
import { StocksService } from './service/stocks.service';

//Guards
import { AuthGuard } from './guard/auth.guard';

@NgModule({
  imports:      [ BrowserModule, FormsModule, HttpModule, AppRoutingModule ],
  declarations: [ AppComponent, LoginComponent, AlertComponent, StocksComponent ],
  providers:    [ LoginService, AlertService, AuthGuard, StocksService ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
